import os
from io import StringIO
from datetime import datetime
import pandas as pd
from azure.storage.blob import BlobServiceClient, ContentSettings
import NseUtility

# Environment variables come from Azure Function App → Configuration
AZURE_CONN_STR = os.getenv("AZURE_CONN_STR")
CONTAINER_NAME = os.getenv("AZURE_CONTAINER_NAME", "nse-data-raw")


def get_blob_service():
    """Return Azure Blob client"""
    return BlobServiceClient.from_connection_string(AZURE_CONN_STR)


def upload_csv_to_azure(df):
    """Convert dataframe to CSV & upload to Azure Blob."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    blob_name = f"metadata/announcements_{timestamp}.csv"

    # Convert dataframe to CSV in-memory
    buffer = StringIO()
    df.to_csv(buffer, index=False)
    csv_data = buffer.getvalue().encode("utf-8")

    # Upload CSV to blob
    blob_service = get_blob_service()
    container_client = blob_service.get_container_client(CONTAINER_NAME)

    if not container_client.exists():
        container_client.create_container()

    blob_client = container_client.get_blob_client(blob_name)
    blob_client.upload_blob(
        csv_data,
        overwrite=True,
        content_settings=ContentSettings(content_type="text/csv")
    )

    print(f"CSV uploaded to Azure: {blob_name}")
    return blob_name


def run_csv_job():
    """Main logic: Fetch NSE announcements and upload CSV."""
    print("Fetching NSE announcements from NSE API...")

    # Create NSE utility instance
    nse = NseUtility.NseUtils()

    # Fetch announcements
    df = nse.get_corporate_announcement()

    if df is None or df.empty:
        print("No announcements received.")
        return

    # Upload CSV to Azure storage
    upload_csv_to_azure(df)

    print("CSV generation + upload completed successfully.")
