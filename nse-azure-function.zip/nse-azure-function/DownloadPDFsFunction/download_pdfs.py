import os
import time
import random
from datetime import datetime
import pandas as pd
import requests
from azure.storage.blob import BlobServiceClient, ContentSettings
from requests.adapters import HTTPAdapter, Retry

# Azure environment variables (in Function App → Configuration)
AZURE_CONN_STR = os.getenv("AZURE_CONN_STR")
CONTAINER_NAME = os.getenv("AZURE_CONTAINER_NAME", "nse-data-raw")

URL_COLUMN = "attchmntFile"
SYMBOL_COLUMN = "symbol"
DATE_COLUMN = "exchdisstime"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/119 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605 Safari/605.1.15",
]

# ------------------------------ #
# 1. Locate latest CSV in Azure Blob
# ------------------------------ #
def get_latest_csv_from_blob():
    service = BlobServiceClient.from_connection_string(AZURE_CONN_STR)
    container = service.get_container_client(CONTAINER_NAME)

    all_blobs = list(container.list_blobs(name_starts_with="metadata/"))

    if not all_blobs:
        print("No CSV found in Azure metadata/")
        return None, None

    # Sort newest first
    all_blobs.sort(key=lambda b: b.last_modified, reverse=True)

    latest_blob = all_blobs[0]
    blob_name = latest_blob.name

    # Download blob data
    csv_bytes = container.download_blob(blob_name).readall()
    print(f"Using latest CSV from Azure → {blob_name}")

    return blob_name, csv_bytes


# ------------------------------ #
# 2. Azure Blob Client
# ------------------------------ #
def get_blob_service():
    return BlobServiceClient.from_connection_string(AZURE_CONN_STR)


# ------------------------------ #
# 3. Request Session
# ------------------------------ #
def create_session():
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
    session.mount("https://", HTTPAdapter(max_retries=retry))
    return session


def is_pdf(data: bytes):
    return data.startswith(b"%PDF")


# ------------------------------ #
# 4. Interpret Date / Quarter
# ------------------------------ #
def parse_dt(s):
    try:
        return datetime.strptime(s, "%d-%b-%Y %H:%M:%S")
    except:
        return datetime.now()


def get_quarter(dt):
    m = dt.month
    if 4 <= m <= 6: return "Q1"
    if 7 <= m <= 9: return "Q2"
    if 10 <= m <= 12: return "Q3"
    return "Q4"


def safe_path(symbol, dt, filename):
    q = get_quarter(dt)
    year = dt.year
    return f"documents/{symbol}/{year}/{q}/{filename}"


# ------------------------------ #
# 5. Download PDF
# ------------------------------ #
def download_pdf(url):
    session = create_session()
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Referer": "https://www.nseindia.com/"
    }

    r = session.get(url, headers=headers, timeout=20, stream=True)
    if r.status_code != 200:
        print(f"HTTP Error {r.status_code}")
        return None

    data = b"".join(chunk for chunk in r.iter_content(4096) if chunk)

    if not is_pdf(data):
        print("Not a PDF (HTML/XML returned)")
        return None

    return data


# ------------------------------ #
# 6. Process CSV → Upload PDFs
# ------------------------------ #
def run_pdf_job():
    blob_name, csv_bytes = get_latest_csv_from_blob()

    if not blob_name:
        print("No CSV available to process.")
        return

    # convert bytes → dataframe
    df = pd.read_csv(pd.io.common.BytesIO(csv_bytes), dtype=str, keep_default_na=False)

    blob_service = get_blob_service()
    container_client = blob_service.get_container_client(CONTAINER_NAME)

    for _, row in df.iterrows():
        url = (row.get(URL_COLUMN) or "").strip()
        symbol = row.get(SYMBOL_COLUMN, "UNKNOWN")
        dt = parse_dt(row.get(DATE_COLUMN, ""))

        if not url:
            continue

        filename = url.split("/")[-1]
        blob_path = safe_path(symbol, dt, filename)
        blob_client = container_client.get_blob_client(blob_path)

        if blob_client.exists():
            print(f"SKIP: {blob_path}")
            continue

        print(f"Downloading {filename} ...")
        pdf_data = download_pdf(url)
        if not pdf_data:
            print(f"FAILED: {url}")
            continue

        blob_client.upload_blob(
            pdf_data,
            overwrite=True,
            content_settings=ContentSettings(content_type="application/pdf")
        )

        print(f"Uploaded: {blob_path}")
