import requests
import pandas as pd
from datetime import datetime, timedelta
from io import StringIO
import zipfile

class NseUtils:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://www.nseindia.com/',
            'Upgrade-Insecure-Requests': "1",
            "DNT": "1",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*,q=0.8",
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive'
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        # Visit homepage to initialize session cookies
        try:
            self.session.get("https://www.nseindia.com", timeout=10)
        except Exception as e:
            print(f"Error initializing session: {e}")

    def get_corporate_announcement(self, from_date_str: str = None, to_date_str: str = None):
        # Fetch Corporate Announcements data from NSE
        if from_date_str is None:
            from_date  = datetime.now() - timedelta(days=2) # Fetches last 2 days by default
            from_date_str = from_date.strftime("%d-%m-%Y")
        if to_date_str is None:
            to_date_str = datetime.now().strftime("%d-%m-%Y")
        
        try:
            # Use the session directly (cookies are handled automatically)
            url = f'https://www.nseindia.com/api/corporate-announcements?index=equities&from_date={from_date_str}&to_date={to_date_str}'
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                return pd.DataFrame(response.json())
            else:
                print(f"NSE Error {response.status_code}: {response.text[:100]}")
                return None
        except Exception as e:
            print(f"Error fetching Corporate Announcements: {e}")
            return None

    def download_document(self, attachment_url):
        """Helper to download the actual PDF content"""
        full_url = f"https://www.nseindia.com/content/corporate/{attachment_url}"
        try:
            response = self.session.get(full_url, timeout=15)
            if response.status_code == 200:
                return response.content
            return None
        except Exception as e:
            print(f"Error downloading PDF {attachment_url}: {e}")
            return None